
clc;
clear all;

    % Material Properties of the Fluid 
    % Density of the Fluid 
    rho =   1000.0;
    % Dynamic Viscosity of the Fluid 
    mu  =   0.00102;
    % Kinematic Viscosity of the Fluid 
    nu  =   mu/rho;

    fprintf('Density of the Fluid, RHO [kg/m3] = %g\n', rho);
    fprintf('Dynamic Viscosity of the Fluid, MU [Pas] = %g\n', mu);
    fprintf('Kinematic Viscosity of the Fluid, NU [m2/s] = %g\n', nu);
    
    % Given Dimensions of channel 
    %Lenght of channel [m]
    L   =   0.25;
    %Height of channel [m]
    H   =   0.45;
    %Width of channel [m]
    Wch   =   1.0;

    fprintf('Lenght of channel L [m] = %g\n', L);
    fprintf('Height of channel H [m] = %g\n', H);
    fprintf('Width of channel W [m] = %g\n', Wch);

    % Reynolds Number 
    Re  =   350.0;
    fprintf('Reynolds Number Re = g\n', Re);

    % Average Velocity of the Fluid 
    uavg=   (Re * nu) / (2*H); % confirm the formula
    fprintf('Average Velocity of the fluid flow Uavg [m/s] = %g\n', uavg);

    % Change in Pressure Delta P 
    dP  =   (12.0 * uavg * mu * L)/(H^2);
    fprintf('Change in Pressure DeltaP [Pa] = %g\n', dP);

    % Volume Flow Rate 
    Q   =   (Wch * dP * H^3.0)/(12.0 * mu * L);
    fprintf('Volume Flow Rate Q [m3/s] = %g\n', Q);
    
    % Hydrodynamic Development Length
    le = H*0.06*Re;
    fprintf('Hydrodynamic Length of the channel = %g\n', le);

     %--%
    % Grid Generation 
    n_cells =   51;
    y       =   linspace(-H/2, H/2, n_cells);
    delY    =   abs(y(2) - y(1));
    fprintf('Grid Spacing (dy) = %g\n', delY);
      
    % Analytical Solution + Numerical Results Comparison 
    u               =   zeros(1,length(y));
    u(1,1)          =   0;
    u(1,length(y))  =   0;
    %K               =   - dP/(mu * l);
    umax = 0;
    %yatumax = 0;

    for i = 1:(length(y))
        u(1,i) = (- dP/(mu * L)) * (((y(i)^2)/2) - ((H^2)/8));
    end

   % Create the output table
    output_table = table(y', u', 'VariableNames', {'Radial_Coordinate', 'Axial_Velocity'});
    csv_filename = 'velocity_profile.csv'; 
    writetable(output_table, csv_filename); 
    
    %Plot Analytical Velocity rofile
    fprintf('The velocity profile with column names has been saved to %s\n', csv_filename);
    
    umax = max(u);
    fprintf('maximum velocity of the fluid flow Umax[m/s] = %g\n', umax);
    figure(1);
    ax = axes;
    
    % Plot data
    plot(y, u, '-.', 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5);
    hold on;
    
    xlabel('Radial Coordinates (m)');
    ylabel('Velocity (m/s)');
    ax.FontSize = 12;
    ax.XLim = [-0.25 0.25];
    ax.YLim = [0 0.00065];
    plot([0 0], ax.YLim, '--', 'Color', [0.9290 0.6940 0.1250]);
    plot(ax.XLim, [umax umax],  '-.', 'Color', 'black');
    xt = [-0.245 0.000615];  
    xt2 = [-0.245 0.000575];
    str = 'uamx=0.000595m/s';  
    text(xt(1),xt(2),str, 'FontSize', 12)
    set(gcf, 'Units', 'inches', 'Position', [0, 0, 6, 4.5]);
    box on;
    grid on;
    legend('Analytical Solution', 'y-axis', 'Location', 'south');
    zp = BaseZoom();%include this the 'BaseZoom.m' filw when needed
    %%zp.run;
         

   %Plot multiple graphs with data from, Fluent
   %2nd Order Outflow Condition - coarse med Fine

     %  %Coarse Mesh - Outflow Conditon - 2nd Order
    figure(3);
    ax=axes;
    plot(y, u, '-.', 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5);
    hold on;
    load('CO2.mat', 'CO2');
    CO2x = CO2.YM;
    CO2y = CO2.VelocityMS1;
    CO2ymax = max(CO2y);
    fprintf('Maximum Velocity in Coarse Mesh- Outflow - 2nd Order Condition = %g\n', CO2ymax);
    plot(CO2x, CO2y, '-','Color', 'k', 'LineWidth',2);
    xlabel('Radial Coordinates (m)');
    ylabel('Velocity (m/s)');
    ax.FontSize = 12;
    ax.XLim = [-0.3 0.3];
    ax.YLim = [0 0.0007];

   %Medium Mesh - Outflow Conditon - 2nd Order
   load('MO2.mat', 'MO2');
    MO2x = MO2.YM;
    MO2y = MO2.VelocityMS1;
    MO2ymax = max(MO2y);
    fprintf('Maximum Velocity in Medium Mesh- Outflow - 2nd Order Condition = %g\n', MO2ymax);
    plot(MO2x, MO2y, '-.','Color', 'g', 'LineWidth',2);

   %Fine Mesh - Outflow Conditon - 2nd Order
    load('FO2.mat', 'FO2');
    FO2x = FO2.YM;
    FO2y = FO2.VelocityMS1;
    FO2ymax = max(FO2y);
    fprintf('Maximum Velocity in Fine Mesh- Outflow - 2nd Order Condition = %g\n', FO2ymax);
    plot(FO2x, FO2y, '-','Color', 'r', 'LineWidth',2);

    set(gcf, 'Units', 'inches', 'Position', [1, 1, 6.4, 4.8]);
    box on;
    grid on;
    legend('Analytical Solution','Coarse Grid', 'Medium Grid', 'Fine Grid', 'Location', 'northwest');
    %zp = BaseZoom();
    %%zp.run

    % 2nd Order Pressure Outlet Condition - coarse med Fine

     %  %Coarse Mesh -Pressure Outlet Conditon - 2nd Order
    figure(4);
    ax=axes;
    plot(y, u, '-.', 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5);
    hold on;
     load('CP2.mat', 'CP2');
    CP2x = CP2.YM;
    CP2y = CP2.VelocityMS1;
    CP2ymax = max(CP2y);
    fprintf('Maximum Velocity in Coarse Mesh- Pressure Outlet - 2nd Order Condition = %g\n', CP2ymax);
    plot(CP2x, CP2y, '-','Color', 'k', 'LineWidth',2);
    xlabel('Radial Coordinates (m)');
    ylabel('Velocity (m/s)');
    ax.FontSize = 12;
    ax.XLim = [-0.3 0.3];
    ax.YLim = [0 0.0007];

   %Medium Mesh - Pressure Outlet - 2nd Order
   load('MP2.mat', 'MP2');
    MP2x = MP2.YM;
    MP2y = MP2.VelocityMS1;
    MP2ymax = max(MP2y);
    fprintf('Maximum Velocity in Medium Mesh- Pressure Outletw - 2nd Order Condition = %g\n', MP2ymax);
    plot(MP2x, MP2y, '-.','Color', 'g', 'LineWidth',2);

   %Fine Mesh - Pressure Outlet Conditon - 2nd Order
    load('FP2.mat', 'FP2');
    FP2x = FP2.YM;
    FP2y = FP2.VelocityMS1;
    FP2ymax = max(FP2y);
    fprintf('Maximum Velocity in Fine Mesh- Pressure Outlet - 2nd Order Condition = %g\n', FP2ymax);
    plot(FP2x, FP2y, '-','Color', 'r', 'LineWidth',2);

    set(gcf, 'Units', 'inches', 'Position', [1, 1, 6.4, 4.8]);
    box on;
    grid on;
    legend('Analytical Solution','Coarse Grid', 'Medium Grid', 'Fine Grid', 'Location', 'northwest');
    zp = BaseZoom();
    %zp.run

   % 1st Order vs second order

     %  %Coarse Mesh -Pressure Outlet 
    figure(5);
    ax=axes;
    plot(y, u, '-.', 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5);
    hold on;
    load('CP1.mat', 'CP1');
    CP1x = CP1.YM;
    CP1y = CP1.VelocityMS1;
    CP1ymax = max(CP1y);
    fprintf('Maximum Velocity in Coarse Mesh- Pressure Outlet - 1st Order Condition = %g\n', CP1ymax);
    plot(CP1x, CP1y, '-','Color', 'r', 'LineWidth',2);

    %plot CP2 again
    plot(CP2x, CP2y, '-.','Color', 'g', 'LineWidth',2);

    xlabel('Radial Coordinates (m)');
    ylabel('Velocity (m/s)');
    ax.FontSize = 12;
    ax.XLim = [-0.3 0.3];
    ax.YLim = [0 0.0007];
    set(gcf, 'Units', 'inches', 'Position', [1, 1, 6.4, 4.8]);
    box on;
    grid on;
    legend('Analytical Solution','Pressure 1st Order', 'Pressure 2nd Order', 'Location', 'northwest');
    zp = BaseZoom();
    %zp.run
    
     %  %Coarse Mesh -Outflow

    figure(6);
    ax=axes;
    plot(y, u, '-.', 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5);
    hold on;
    load('CO1.mat', 'CO1');
    CO1x = CO1.YM;
    CO1y = CO1.VelocityMS1;
    CO1ymax = max(CO1y);
    fprintf('Maximum Velocity in Coarse Mesh- Outflow - 1st Order Condition = %g\n', CO1ymax);
    plot(CO1x, CO1y, '-','Color', 'r', 'LineWidth',2);

    %plot CO2 again
    plot(CO2x, CO2y, '-.','Color', 'g', 'LineWidth',2);

    xlabel('Radial Coordinates (m)');
    ylabel('Velocity (m/s)');
    ax.FontSize = 12;
    ax.XLim = [-0.3 0.3];
    ax.YLim = [0 0.0007];
    set(gcf, 'Units', 'inches', 'Position', [1, 1, 6.4, 4.8]);
    box on;
    grid on;
    legend('Analytical Solution','Outflow 1st Order', 'Outflow 2nd Order', 'Location', 'northwest');
    zp = BaseZoom();
    %zp.run

 
   
    %NonIsothermal Condition Temperature Distribution
    figure(10);
    ax=axes;
    load('TempvsY.mat', 'TempvsY');
    TYx = TempvsY.YM;
    TYy = TempvsY.TemperatureK;
    plot(TYx, TYy, '-o','Color', [0.8500 0.3250 0.0980], 'MarkerFaceColor', [0.8500 0.3250 0.0980]);
    xlabel('Radial coordinates(m)');
    ylabel('Temperature(K)');
    hold on;
    %title('Temperature Distribution');
    ax.FontSize = 12;
    ax.XLim = [-0.25 0.25];
    ax.YLim = [0 360];
    plot([0 0], ax.YLim, '--', 'Color', [0.9290 0.6940 0.1250]);
    set(gcf, 'Units', 'inches', 'Position', [0, 0, 6, 4.5]);
    box on;
    grid on;
    legend('Temperature Distribution', 'y-axis', 'Location', 'south');
   % 


    %Error
    %Flip Analytical Solution data to match co=ordinates with numericalData
    load ('VeloPro.mat', 'VeloPro');
    Uan_flip_Y = flipud(VeloPro.Axial_Velocity);

    %Absolute Error CO1
    AE_CO1_mtx = abs(Uan_flip_Y-CO1y);
    AE_CO1_mean = mean(AE_CO1_mtx);
    fprintf('Absolute Error for Coarse Mesh-Outflow-1st Order = %g\n', AE_CO1_mean);

    %Absolute Error CO2
    AE_CO2_mtx = abs(Uan_flip_Y-CO2y);
    AE_CO2_mean = mean(AE_CO2_mtx);
    fprintf('Absolute Error for Coarse Mesh-Outflow-2nd Order = %g\n', AE_CO2_mean);

     %Absolute Error CP1
    AE_CP1_mtx = abs(Uan_flip_Y-CP1y);
    AE_CP1_mean = mean(AE_CP1_mtx);
    fprintf('Absolute Error for Coarse Mesh-PressureOutlet-1st Order = %g\n', AE_CP1_mean);

    %Absolute Error CP2
    AE_CP2_mtx = abs(Uan_flip_Y-CP2y);
    AE_CP2_mean = mean(AE_CP2_mtx);
    fprintf('Absolute Error for Coarse Mesh-PressureOutlet-2nd Order = %g\n', AE_CP2_mean);
    

     %Absolute Error MP2
     AE_MP2_mtx = abs(Uan_flip_Y -  MP2y);
    AE_MP2_mean = mean(AE_MP2_mtx);
    fprintf('Absolute Error for Medium Mesh-PressureOutlet-2nd Order = %g\n', AE_MP2_mean);
   

    %Absolute Error MO2
    AE_MO2_mtx = abs(Uan_flip_Y-MO2y);
    AE_MO2_mean = mean(AE_MO2_mtx);
    fprintf('Absolute Error for Medium Mesh-Outflow-2nd Order = %g\n', AE_MO2_mean);

      %Absolute Error FP2
    AE_FP2_mtx = abs(Uan_flip_Y -  FP2y);
    AE_FP2_mean = mean(AE_FP2_mtx);
    fprintf('Absolute Error for Fine Mesh-PressureOutlet-2nd Order = %g\n', AE_FP2_mean);

    %Absolute Error FO2
    AE_FO2_mtx = abs(Uan_flip_Y-FO2y);
    AE_FO2_mean = mean(AE_FO2_mtx);
    fprintf('Absolute Error for Fine Mesh-Outflow - 2nd Order = %g\n', AE_FO2_mean);
    figure(11);
    ax = axes;
    xRE_BAr = categorical({'Coarse Grid', 'Medium Grid', 'Fine Grid'});
    xRE_BAr = reordercats(xRE_BAr,{'Coarse Grid', 'Medium Grid', 'Fine Grid'});
    yRE_BAr = [AE_CP1_mean, AE_CO1_mean, AE_CP2_mean, AE_CO2_mean;0,0, AE_MP2_mean, AE_MO2_mean;0,0, AE_FP2_mean, AE_FO2_mean];
    AEBar = bar(xRE_BAr ,yRE_BAr);
    legend('Pressure Outlet-1st Order', 'Outflow-1st Order', 'Pressure Outlet-2nd Order', 'Outflow-2nd Order');
    xlabel('Grid Resolution');
    ylabel('Absolute Error');
    ax.FontSize = 12;
    set(gcf, 'Units', 'inches', 'Position', [0, 0, 6, 4.5]);
    box on;

    %Relative Error Calculation

      %Relative Error CO1
    RE_CO1 = 100*abs(AE_CO1_mean/(umax));
       fprintf('Relative Error for Coarse Mesh-Outflow-1st Order = %g\n', RE_CO1);

    %Relative Error CO2
    RE_CO2 = 100*abs(AE_CO2_mean/(umax));
    fprintf('Relative Error for Coarse Mesh-Outflow-2nd Order = %g\n', RE_CO2);

     %Relative Error CP1
    RE_CP1 = 100*abs(AE_CP1_mean/(umax));
    fprintf('Relative Error for Coarse Mesh-PressureOutlet-1st Order = %g\n', RE_CP1);

     %Relative Error CP2
    RE_CP2 = 100*abs(AE_CP2_mean/(umax));
    fprintf('Relative Error for Coarse Mesh-PressureOutlet-2nd Order = %g\n', RE_CP2);

     %Relative Error MP2
    RE_MP2 = 100*abs(AE_MP2_mean/(umax));
    fprintf('Relative Error for Medium Mesh-PressureOutlet-2nd Order = %g\n', RE_MP2);

     %Relative Error MO2
    RE_MO2 = 100*abs(AE_MO2_mean/(umax));
    fprintf('Relative Error for Medium Mesh-Outflow-2nd Order = %g\n', RE_MO2);

    %Relative Error FP2
    RE_FP2 = 100*abs(AE_FP2_mean/(umax));
    fprintf('Relative Error for Fine Mesh-PressureOutlet-2nd Order = %g\n', RE_FP2);

    %Relative Error FO2
    RE_FO2 = 100*abs(AE_FO2_mean/(umax));
    fprintf('Relative Error for Fine Mesh-Outflow-2nd Order = %g\n', RE_FO2);

    figure(12);
    ax = axes;
    
    xRE_BAr = categorical({'Coarse Grid', 'Medium Grid', 'Fine Grid'});
    xRE_BAr = reordercats(xRE_BAr,{'Coarse Grid', 'Medium Grid', 'Fine Grid'});
    yRE_BAr = [RE_CP1, RE_CO1, RE_CP2, RE_CO2; 0, 0, RE_MP2, RE_MO2;0, 0, RE_FP2, RE_FO2];
    AEBar = bar(xRE_BAr ,yRE_BAr);
    legend('Pressure Outlet-1st Order', 'Outflow-1st Order', 'Pressure Outlet-2nd Order', 'Outflow-2nd Order');
    xlabel('Grid Resolution');
    ylabel('Relative Error (%)');
    ax.FontSize = 12;
    set(gcf, 'Units', 'inches', 'Position', [0, 0, 6, 4.5]);
    box on;